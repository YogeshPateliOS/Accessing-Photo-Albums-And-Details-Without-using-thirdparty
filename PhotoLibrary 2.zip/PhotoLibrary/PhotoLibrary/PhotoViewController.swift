//
//  PhotoViewController.swift
//  PhotoLibrary
//
//  Created by Solulab on 2/24/20.
//  Copyright © 2020 YogeshPatel. All rights reserved.
//

import UIKit
import Photos
class PhotoViewController: BaseClass {

    @IBOutlet weak var collectionView: UICollectionView!
    var arrPhotos = [PHAsset](){
        didSet{
            if collectionView != nil{
                collectionView.reloadData()
            }
        }
    }
    var fetchResult = PHFetchResult<PHAsset>(){
        didSet{
            for i in 0..<fetchResult.count{
                arrPhotos.append(fetchResult[i])
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(self.reloadData(notification:)), name: Notification.Name("PhotosUpdating"), object: nil)
    }

    @objc func reloadData(notification: Notification) {
        if let arr = notification.userInfo?["UpdatedArr"] as? PHFetchResult<PHAsset>{
            arrPhotos.removeAll()
            fetchResult = arr
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
        super.viewDidDisappear(animated)
    }

}

extension PhotoViewController: UICollectionViewDataSource{

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        arrPhotos.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as? CollectionViewCell else { return UICollectionViewCell() }
            cell.img.image = getImageFromAsset(asset: arrPhotos[indexPath.row])
        return cell
    }

}

extension PhotoViewController:UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if arrPhotos[indexPath.row].mediaType == .video{
            playVideo(view: self, asset: arrPhotos[indexPath.row])
        }else{
            let imageView = UIImageView(image: getImageFromAsset(asset: arrPhotos[indexPath.row]))
              imageView.frame = self.view.frame
              imageView.backgroundColor = .black
              imageView.contentMode = .scaleAspectFit
              imageView.isUserInteractionEnabled = true

              let tap = UITapGestureRecognizer(target: self, action: #selector(dismissFullscreenImage))
              imageView.addGestureRecognizer(tap)

              self.view.addSubview(imageView)
        }
        debugPrint("Yeah!!")
    }

    @objc func dismissFullscreenImage(_ sender: UITapGestureRecognizer) {
        sender.view?.removeFromSuperview()
    }
}

extension PhotoViewController: UICollectionViewDelegateFlowLayout{

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.bounds.width/3, height: collectionView.bounds.width/3)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
