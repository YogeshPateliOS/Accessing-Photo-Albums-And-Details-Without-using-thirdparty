//
//  TableViewCell.swift
//  PhotoLibrary
//
//  Created by Solulab on 2/24/20.
//  Copyright © 2020 YogeshPatel. All rights reserved.
//

import UIKit
import Photos

class TableViewCell: UITableViewCell {

    @IBOutlet weak var albumImage: UIImageView!
    @IBOutlet weak var albumTitle: UILabel!
    @IBOutlet weak var albumCount: UILabel!
    var photoModel:PhotosModel?{
        didSet{
            updateUI()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func updateUI(){
        albumTitle.text = photoModel?.title
        albumCount.text = "\(photoModel?.count ?? 0)"
        if (photoModel?.imageArr.count)! > 0{
            if let asset = photoModel?.imageArr.firstObject{
                albumImage?.image = getImageFromAsset(asset: asset)
            }else{
                albumImage.image = #imageLiteral(resourceName: "NO_Image")
            }
        }else{
            albumImage.image = #imageLiteral(resourceName: "NO_Image")
        }
    }

}

extension UITableViewCell {
    func getImageFromAsset(asset:PHAsset) -> UIImage{
        var img = UIImage()
        PHCachingImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 200, height: 200), contentMode: .aspectFill, options: nil) { (image, _) in
            if let renderImg = image{
                img = renderImg
            }
        }
        return img
    }
}
