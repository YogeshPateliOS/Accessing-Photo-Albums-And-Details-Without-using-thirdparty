//
//  BaseClass.swift
//  PhotoLibrary
//
//  Created by Solulab on 2/24/20.
//  Copyright © 2020 YogeshPatel. All rights reserved.
//

import Foundation
import UIKit
import Photos
import AVKit

class BaseClass: UIViewController{
    let imgManager = PHImageManager.default()

    func getImageFromAsset(asset:PHAsset) -> UIImage{
           var img = UIImage()
           PHCachingImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 200, height: 200), contentMode: .aspectFill, options: nil) { (image, _) in
               if let renderImg = image{
                   img = renderImg
               }
           }
           return img
       }

    func playVideo(view:UIViewController, asset:PHAsset) {
        
        guard (asset.mediaType == .video)
            else {
                debugPrint("Not a valid video media type")
                return
        }
        PHCachingImageManager.default().requestAVAsset(forVideo: asset, options: nil) { (avAsset, autioMix, info) in
            DispatchQueue.main.async {
                let player = AVPlayer(url: (avAsset as? AVURLAsset)!.url)
                let playerViewController = AVPlayerViewController()
                playerViewController.player = player
                view.present(playerViewController, animated: true) {
                    playerViewController.player?.play()
                }
            }
        }
    }
}
