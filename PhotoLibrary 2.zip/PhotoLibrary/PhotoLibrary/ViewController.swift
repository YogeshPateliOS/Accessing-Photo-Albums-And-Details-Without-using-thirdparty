//
//  ViewController.swift
//  PhotoLibrary
//
//  Created by Solulab on 2/24/20.
//  Copyright © 2020 YogeshPatel. All rights reserved.
//

import UIKit
import Photos

struct PhotosModel{
    var title: String
    var count: Int
    var imageArr = PHFetchResult<PHAsset>()
}

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var arrImages = [PhotosModel]()

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func viewWillAppear(_ animated: Bool) {
        getImagesWithTitles(type: .album)
        getImagesWithTitles(type: .smartAlbum)
        tableView.reloadData()
        PHPhotoLibrary.shared().register(self)
        super.viewWillAppear(animated)
    }

    func getImagesWithTitles(type: PHAssetCollectionType){
        let albumList = PHAssetCollection.fetchAssetCollections(with: type, subtype: .albumRegular, options: nil)
        albumList.enumerateObjects { (coll, _, _) in
            let result = self.getAssets(fromCollection: coll)
            let photoModel = PhotosModel(title: coll.localizedTitle ?? "", count: result.count, imageArr: result)
            self.arrImages.append(photoModel)
        }
    }

    func getAssets(fromCollection collection: PHAssetCollection) -> PHFetchResult<PHAsset> {
        let photosOptions = PHFetchOptions()
        photosOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
        photosOptions.predicate = NSPredicate(format: "mediaType = %d || mediaType = %d", PHAssetMediaType.image.rawValue, PHAssetMediaType.video.rawValue)
        return PHAsset.fetchAssets(in: collection, options: photosOptions)
    }

}


extension ViewController: UITableViewDataSource{


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrImages.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as? TableViewCell else { return UITableViewCell() }
        cell.photoModel = arrImages[indexPath.row]
        debugPrint("asdasd",indexPath.row)
        return cell
    }

}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let photoVC = self.storyboard?.instantiateViewController(identifier: "PhotoViewController") as? PhotoViewController {
            photoVC.fetchResult = arrImages[indexPath.row].imageArr
            self.navigationController?.pushViewController(photoVC, animated: true)
        }
    }
}

extension ViewController: PHPhotoLibraryChangeObserver{
    func photoLibraryDidChange(_ changeInstance: PHChange) {
        DispatchQueue.main.async {
            for i in 0..<self.arrImages.count{
                let fetchResultChangeDetails = changeInstance.changeDetails(for: self.arrImages[i].imageArr)
                if (fetchResultChangeDetails) != nil{
                    let v1 = (fetchResultChangeDetails?.fetchResultAfterChanges)!
                    if self.arrImages[i].imageArr.count != v1.count{
                        self.arrImages[i].imageArr = v1
                        self.arrImages[i].count = v1.count
                        if let topVC = UIApplication.getTopViewController(){
                            if topVC.isKind(of: ViewController.classForCoder()){
                                let indexPath = IndexPath(row: i, section: 0)
                                self.tableView.reloadRows(at: [indexPath], with: .fade)
                            }else if topVC.isKind(of: PhotoViewController.classForCoder()){
                                NotificationCenter.default.post(name: Notification.Name("PhotosUpdating"), object: nil, userInfo: ["UpdatedArr":v1])
                            }
                        }
                    }

                } else {
                    debugPrint("No change in fetchResultChangeDetails")
                }
            }
        }
    }
}

extension UIApplication {

    class func getTopViewController(base:
        UIViewController? = UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController
    ) -> UIViewController? {

        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)

        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)

        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}
