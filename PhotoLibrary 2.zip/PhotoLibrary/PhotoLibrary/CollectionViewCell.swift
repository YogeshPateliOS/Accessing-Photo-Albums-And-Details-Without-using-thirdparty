//
//  CollectionViewCell.swift
//  PhotoLibrary
//
//  Created by Solulab on 2/24/20.
//  Copyright © 2020 YogeshPatel. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!

}
